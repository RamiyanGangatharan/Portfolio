<?php
  $file = __FILE__;
  $date = "Friday, January, 13, 2023";
  $title = "Making an Error";
  $description = "This is the webpage for lab 4";
  $banner = "Error Script 1";
?>

<?php include('./header.php')?>

<?php
    echo "<p>I am trying to produce an error</p>";
    echo "<p>Was I successful?</p>";
?>

<?php include('./footer.php')?>