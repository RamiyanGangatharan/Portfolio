<?php
/* Return the temperature calculation */
function conversion ($temp) 
{
    return 9.0 / 5.0 * $temp + 32;
}
?>
