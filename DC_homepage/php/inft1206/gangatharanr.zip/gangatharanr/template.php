<?php
  $file = __FILE__;
  $date = "Friday, January, 13, 2023";
  $title = "Index";
  $description = "This is the webpage for my homepage";
  $banner = " Web Development Fundamentals Homepage";
?>

<?php include('./header.php')?>

<?php 
  //COMMENT GUIDE
  
  //regular comment
  #python style hash comment
  /* C - Style multi-line comment */

 ?>

<!-- HTML COMMENT-->

<?php include('./footer.php')?>