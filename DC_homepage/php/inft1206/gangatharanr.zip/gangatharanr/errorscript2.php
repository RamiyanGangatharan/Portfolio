
<?php
  $file = __FILE__;
  $date = "Friday, January, 13, 2023";
  $title = "Trying For Another Error";
  $description = "This is the webpage for lab 4";
  $banner = "Error Script 2";
?>

<?php include('./header.php')?>

<?php
    echo "<p>I think this is really \"cool\"!</p>"
?>

<?php include('./footer.php')?>