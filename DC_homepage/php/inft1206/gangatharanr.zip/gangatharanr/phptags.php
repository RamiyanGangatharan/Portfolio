<?php
  $file = __FILE__;
  $date = "Friday, January, 13, 2023";
  $title = "Tags";
  $description = "This is the webpage for lab 4";
  $banner = "PHP Tags";
?>

<?php include('./header.php')?>

<?php
    echo "<p>This is a test the PHP tag.</p>"
?>

<?php include('./footer.php')?>