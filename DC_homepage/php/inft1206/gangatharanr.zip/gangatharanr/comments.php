<?php
  $file = __FILE__;
  $date = "Friday, January, 13, 2023";
  $title = "Code Comments";
  $description = "This is the webpage for lab 4";
  $banner = "Commenting";
?>

<?php include('./header.php')?>

<h1>USE INSPECT ELEMENT</h1>
<!-- This is an HTML comment. -->
<?php
    // This is a simple PHP comment.
    /* This is a C-style, multiline comment. You can make this as
    long as you'd like. */
    # Used to shells? Use this kind of comment.
?>

<?php include('./footer.php')?>