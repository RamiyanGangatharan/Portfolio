	<!-- end of main page content -->
		</div>		
			</div>
				<?php echo displayCopyright()?>
			</div>
		</div>
	</body>
</html>